import { BrowserRouter, Routes, Route } from "react-router-dom";
import MainLayout from "./layouts/MainLayout";

// Mantenimiento
import ListarUsuarios from "./pages/mantenimiento/usuario/Listar";
import NuevoUsuario from "./pages/mantenimiento/usuario/Nuevo";
import ListarProductos from "./pages/mantenimiento/producto/Listar";
import NuevoProducto from "./pages/mantenimiento/producto/Nuevo";

// Seguridad
import Roles from "./pages/seguridad/Roles";
import Permisos from "./pages/seguridad/Permisos";

// Reportes
import ReporteVentas from "./pages/reportes/ReporteVentas";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Layout principal */}
        <Route path="/" element={<MainLayout />}>
          {/* Página de inicio */}
          <Route index element={<h1>Bienvenido al sistemaa</h1>} />

          {/* Mantenimiento */}
          <Route path="mantenimiento/usuarios">
            <Route index element={<ListarUsuarios />} />
            <Route path="nuevo" element={<NuevoUsuario />} />
          </Route>

          <Route path="mantenimiento/productos">
            <Route index element={<ListarProductos />} />
            <Route path="nuevo" element={<NuevoProducto />} />
          </Route>

          {/* Seguridad */}
          <Route path="seguridad/roles" element={<Roles />} />
          <Route path="seguridad/permisos" element={<Permisos />} />

          {/* Reportes */}
          <Route path="reportes/ventas" element={<ReporteVentas />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
