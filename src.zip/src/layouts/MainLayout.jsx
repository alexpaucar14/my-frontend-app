import { Outlet } from "react-router-dom";
import TopBar from "../components/TopBar";
import LeftSidebar from "../components/LeftSidebar";

export default function MainLayout() {
  return (
    <div className="app-container">
      <TopBar />
      <div className="content">
        <LeftSidebar />
        <main>
          {/* Aquí se renderizan las páginas hijas */}
          <Outlet />
        </main>
      </div>
    </div>
  );
}
